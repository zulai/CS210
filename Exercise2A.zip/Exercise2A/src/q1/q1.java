/* 
 * CS210 Exercise2 (q1)
 * Zulai Zhang - zhangzulai@gmail.com
 * Student ID: 950684236
 * 2018.01.12 - Winter quarter
 * I use one variable and add "+" "=" to show +,= sings.Becuase without "", + and = can not show up at the output
 * and 2*i will output the 2i.
 * This program writes equations.
 */
package q1;

public class q1 {

	public static void main(String[] args) {
			for (int i = 1; i <= 5; i++){
				System.out.println(i +"+" +i +"="+2*i);
			}
		}
		// TODO Auto-generated method stub

	}
