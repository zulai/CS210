package exercise;

import java.util.Arrays;

public class ThirdQuestion {
	static int max;
	static int min;

	public static void main(String[] args) {
		int[] my_array = { 25, 10, 55, 65, 36, 92, 77, 8, 13, 79 };
		max_min(my_array);
		System.out.println(" Orugunal Array" + Arrays.toString(my_array));
		System.out.println(" Maximum value for the above array = " + max);
		System.out.println(" Minimum value for the above array = " + min);

		// TODO Auto-generated method stub

	}

	private static void max_min(int[] my_array) {
		max = 0;
		for (int i = 0; i <= 9; i++) {
			if (my_array[i] > max) {
				max = my_array[i];
			}
			min = 100;
			for (int j = 0; j <= 9; j++) {
				if (my_array[j] < min) {
					min = my_array[j];
				}
				// TODO Auto-generated method stub

			}

		}
	}
}
