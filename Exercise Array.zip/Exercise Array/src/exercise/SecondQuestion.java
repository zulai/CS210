package exercise;

public class SecondQuestion {

	// TODO Auto-generated method stub
	public static int findIndex(int[] my_array, int t) {
		for (int j = 0; j <= my_array.length; j++) {
			my_array[j] = t;
		}

		return t;

	}

	public static void main(String[] args) {
		int[] my_array = new int[] { 25, 10, 55, 65, 36, 92, 77, 8, 13, 79 };
		System.out.println("Index position of 55 is : " + findIndex(my_array, 55));
		System.out.println("Index position of 13 is : " + findIndex(my_array, 13));
	}
}
