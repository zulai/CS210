package exercise;

public class FirstQuestion {

	public static void main(String[] args) {
		int[] numbers = new int[] { 10, 20, 30, 40, -50, 60, -70 };
		int sumScore = 0;
		for (int i = 0; i <= 6; i++) {
			sumScore = sumScore + numbers[i];
		}
		int average = sumScore / 7;
		System.out.println("Average value of the arrat elements is : "+average);
	}
		// TODO Auto-generated method stub

	}


