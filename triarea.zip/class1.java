package Class;

import java.util.*;

public class class1 {

	public static triarea t = new triarea();
	public static triarea r = new triarea();
	public static triarea c = new triarea();

	public static void main(String[] area) {
		Scanner console = new Scanner(System.in);
		System.out.println("Choose a number below: 1.triangle 2.rectangle 3.circle.");
		int answer = console.nextInt();
		if (answer == 1) {
			System.out.println("What's the width?");
			t.w = console.nextInt();
			System.out.println("What's the length?");
			t.h = console.nextInt();
			double area1 = t.areaRec();
			System.out.println("The area of triangle is " + area1);
		}
		if (answer == 2) {
			System.out.println("What's the width?");
			r.w = console.nextInt();
			System.out.println("What's the length?");
			r.h = console.nextInt();
			double area1 = r.areaRec();
			System.out.println("The area of rectangle is " + area1);
		}
		if (answer==3) {
			System.out.println("What's the radius?");
			c.r=console.nextInt();
			double area1=c.areaCir();
			System.out.println("The area of circle is " + area1);
		}
		console.close();
		// TODO Auto-generated method stub

	}

}
