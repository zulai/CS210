package Class;

public class triarea {
		int w;
		int h;
		int r;
		public double areaTri() {
			double result = w*h/2.0;
			return result;
	}
		public double areaRec() {
			double result = w*h;
			return result;
		}
		public double areaCir() {
			double result = Math.PI*r*r;
			return result;
		}
}
