	package Bonus;
import java.util.*;
public class bonus1 {
	public static change unit = new change();
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		System.out.println("Choose what you want to change here: (type the number infront)");
		System.out.println("1.f2c 2.c2f 3.kg2lb 4.lb2kg");
		int answer = console.nextInt();
		if (answer==1) {
			System.out.println("What's the Fahrenheit degree?");
			unit.c = console.nextDouble();
			double change = unit.f2c();
			System.out.println("The Celsius for" + unit.c +" is " + change+ "��");
		}
		
		if(answer==2) {
			System.out.println("What's the Celsius degree?");
			unit.f = console.nextDouble();
			double change = unit.c2f();
			System.out.println("The Fahrenheit for" + unit.f +" is " + change+ "�H");
		}
		if(answer==3) {
			System.out.println("What's the kg number?");
			unit.kg = console.nextDouble();
			double change = unit.kg2lb();
			System.out.println("The lb for" + unit.kg + " is " + change + "lb");
		}
		if(answer==4) {
			System.out.println("What's the lb number?");
			unit.lb = console.nextDouble();
			double change = unit.lb2kg();
			System.out.println("The kg for" + unit.lb + " is " + change + "kg");
		}	
		// TODO Auto-generated method stub
		console.close();
	}

}
