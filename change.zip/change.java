package Bonus;

public class change {
	double c;
	double f;
	double kg;
	double lb;
	public double c2f() {
		double result = c*9/5+32;
		return result;
	}
	public double f2c() {
		double result = (f-32)*5/9;
		return result;
	}
	public double kg2lb() {
		double result = kg/0.45359237;
		return result;
	}
	public double lb2kg() {
		double result = lb*0.45359237;
		return result;
	}
}
